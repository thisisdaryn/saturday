VOTING_SUBDIVISION_2018_WGS84_readme
 

Column name  (Description)
======================================
AREA_ID = AREA_ID  (Unique area identifier)
AREA_S_CD = AREA_SHORT_CODE  (Voting subdivision ID)
AREA_L_CD = AREA_LONG_CODE  (Municipal Ward number with voting subdivision ID)
AREA_NAME = AREA_NAME  (Voting subdivision name)
OBJECTID = OBJECTID  (System generated unique ID)
